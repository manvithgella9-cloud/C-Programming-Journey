#include<string.h>
#include <stdio.h>

int main()
{
    char s[999];
    char* p;
    char h[999]="";
    fgets(s,999,stdin);
    p=strtok(s," ");
    while(p!=NULL)
    {
        strncat(h,p,1);
        p=strtok(NULL," ");
    }
    puts(h);
    

    
    return 0;
}
